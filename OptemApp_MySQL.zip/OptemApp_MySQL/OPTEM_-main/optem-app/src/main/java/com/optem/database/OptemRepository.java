package com.optem.database;

import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import com.optem.models.Actividad;

/** Consultas reales contra el esquema OPTEM instalado en Ubuntu Server. */
public final class OptemRepository {
    private OptemRepository() {}
    public static Map<String,String> autenticar(String correo, String cuenta, String rol) {
        String sql="SELECT u.correo,u.nombre,u.apellidos,u.numero_cuenta,r.nombre_rol FROM USUARIOS u JOIN ROLES r ON r.id_rol=u.id_rol WHERE LOWER(u.correo)=LOWER(?) AND u.numero_cuenta=?";
        try (Connection c=MySQL.conectar(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,correo); p.setString(2,cuenta);
            try (ResultSet rs=p.executeQuery()) {
                if (!rs.next()) return null;
                String dbRol=rs.getString("nombre_rol");
                String esperado=switch(rol.toUpperCase(Locale.ROOT)) {case "MAESTRO" -> "Docente";case "ADMINISTRADOR" -> "Administrador";default -> "Estudiante";};
                if (!esperado.equalsIgnoreCase(dbRol)) return null;
                Map<String,String> m=new HashMap<>();
                m.put("correo", rs.getString("correo"));m.put("nombre",rs.getString("nombre"));m.put("apellidos",rs.getString("apellidos"));m.put("rol",esperado);return m;
            }
        } catch(SQLException e) {throw new IllegalStateException("No se pudo validar el acceso en MySQL: "+e.getMessage(),e);}
    }
    public static String rolDeUsuario(String correo) {
        if(correo == null || correo.isBlank()) return "ESTUDIANTE";
        String q="SELECT r.nombre_rol FROM USUARIOS u JOIN ROLES r ON r.id_rol=u.id_rol WHERE u.correo=?";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(q)) {
            p.setString(1,correo);try(ResultSet r=p.executeQuery()){
                if(!r.next())return "ESTUDIANTE";
                return switch(r.getString(1)) {case "Administrador" -> "ADMINISTRADOR";case "Docente" -> "MAESTRO";default -> "ESTUDIANTE";};
            }
        }catch(SQLException e){System.err.println("Rol MySQL: "+e.getMessage());return "ESTUDIANTE";}
    }
    public static boolean existeUsuario(String correo) {
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT 1 FROM USUARIOS WHERE correo=?")) {
            p.setString(1,correo);try(ResultSet r=p.executeQuery()){return r.next();}
        } catch(SQLException e){System.err.println("No se pudo verificar sesión: "+e.getMessage());return false;}
    }
    public static Map<String,String> perfil(String correo) {
        Map<String,String> m=new HashMap<>();
        m.put("nombre_completo", "");m.put("carrera", "");m.put("promedio_general", "N/D");m.put("avance_creditos", "N/D");m.put("situacion", "Sin información");m.put("semestre", "N/D");m.put("numero_cuenta", "N/D");m.put("correo", correo==null?"":correo);
        if(correo==null||correo.isBlank())return m;
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT nombre,apellidos,carrera,semestre,numero_cuenta,xp_total,racha_dias FROM USUARIOS WHERE correo=?")){
            p.setString(1,correo);try(ResultSet r=p.executeQuery()){if(r.next()){m.put("nombre_completo",r.getString(1)+" "+r.getString(2));m.put("carrera",Objects.toString(r.getString(3),""));m.put("situacion","Registrado");m.put("semestre",r.getObject("semestre")==null?"N/D":r.getString("semestre"));m.put("numero_cuenta",Objects.toString(r.getString("numero_cuenta"),"N/D"));m.put("xp_total",r.getString("xp_total"));m.put("racha_dias",r.getString("racha_dias"));}}
        }catch(SQLException e){System.err.println("Perfil: "+e.getMessage());}
        return m;
    }
    public static List<Map<String,String>> materias(String correo) {
        List<Map<String,String>> datos=new ArrayList<>();
        if(correo==null||correo.isBlank()) return datos;
        String sql="SELECT m.clave_materia,m.nombre_materia,g.nombre_grupo,g.horario_texto,CONCAT_WS(' ',u.nombre,u.apellidos) docente,g.id_grupo FROM CARGA_ACADEMICA ca JOIN GRUPOS g ON g.id_grupo=ca.id_grupo JOIN MATERIAS m ON m.clave_materia=g.clave_materia LEFT JOIN USUARIOS u ON u.correo=g.correo_docente WHERE ca.correo_estudiante=? AND ca.estado_inscripcion='inscrito' ORDER BY m.nombre_materia";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,correo);try(ResultSet r=p.executeQuery()){while(r.next()){
                Map<String,String> m=new HashMap<>();m.put("clave",r.getString(1));m.put("nombre",r.getString(2));m.put("grupo",r.getString(3));m.put("horario",Objects.toString(r.getString(4),"Sin horario"));m.put("profesor",Objects.toString(r.getString(5),"Sin docente asignado"));
                m.put("id_grupo",r.getString("id_grupo"));m.put("reunion", "");m.put("tarea", "");m.put("mensaje", "");datos.add(m);
            }}
        }catch(SQLException e){System.err.println("Materias: "+e.getMessage());}
        return datos;
    }
    public static List<Map<String,String>> gruposDocente(String correo) {
        List<Map<String,String>> result=new ArrayList<>();
        if(correo==null || correo.isBlank())return result;
        String sql="SELECT g.id_grupo,m.nombre_materia,g.nombre_grupo,g.horario_texto, " +
                "(SELECT COUNT(*) FROM CARGA_ACADEMICA ca WHERE ca.id_grupo=g.id_grupo AND ca.estado_inscripcion='inscrito') alumnos " +
                "FROM GRUPOS g JOIN MATERIAS m ON m.clave_materia=g.clave_materia WHERE g.correo_docente=? AND g.archivado=0 ORDER BY m.nombre_materia";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,correo);try(ResultSet r=p.executeQuery()){while(r.next()) {
                Map<String,String> row=new HashMap<>();row.put("id_grupo",r.getString(1));row.put("nombre",r.getString(2));
                row.put("grupo",r.getString(3));row.put("horario",Objects.toString(r.getString(4),"Sin horario"));
                row.put("alumnos",r.getString(5));result.add(row);
            }}
        }catch(SQLException e){System.err.println("Grupos docente: "+e.getMessage());}
        return result;
    }

    /** Alumnos realmente inscritos en un grupo del docente activo. */
    public static List<String> alumnosGrupoDocente(String docente,int idGrupo) {
        List<String> alumnos=new ArrayList<>();
        String sql="SELECT CONCAT_WS(' ',u.nombre,u.apellidos),u.numero_cuenta FROM CARGA_ACADEMICA ca " +
            "JOIN USUARIOS u ON u.correo=ca.correo_estudiante JOIN GRUPOS g ON g.id_grupo=ca.id_grupo " +
            "WHERE g.id_grupo=? AND g.correo_docente=? AND ca.estado_inscripcion='inscrito' " +
            "ORDER BY u.apellidos,u.nombre";
        try(Connection c=MySQL.conectar();PreparedStatement ps=c.prepareStatement(sql)) {
            ps.setInt(1,idGrupo);ps.setString(2,docente);
            try(ResultSet rs=ps.executeQuery()) {while(rs.next())alumnos.add(rs.getString(1)+" · "+rs.getString(2));}
        }catch(SQLException e){System.err.println("Alumnos grupo: "+e.getMessage());}
        return alumnos;
    }
    public static boolean actualizarHorarioDocente(String docente,int grupo,String horario) {
        if(horario==null || horario.isBlank() || horario.length()>255)return false;
        try(Connection c=MySQL.conectar();PreparedStatement ps=c.prepareStatement(
                "UPDATE GRUPOS SET horario_texto=? WHERE id_grupo=? AND correo_docente=? AND archivado=0")) {
            ps.setString(1,horario.trim());ps.setInt(2,grupo);ps.setString(3,docente);
            return ps.executeUpdate()==1;
        }catch(SQLException e){System.err.println("Horario: "+e.getMessage());return false;}
    }
    public static boolean archivarGrupoDocente(String docente,int grupo) {
        try(Connection c=MySQL.conectar();PreparedStatement ps=c.prepareStatement(
                "UPDATE GRUPOS SET archivado=1 WHERE id_grupo=? AND correo_docente=? AND archivado=0")) {
            ps.setInt(1,grupo);ps.setString(2,docente);return ps.executeUpdate()==1;
        }catch(SQLException e){System.err.println("Archivar: "+e.getMessage());return false;}
    }
    public static int tareasPendientesDocente(String correo) {
        String sql="SELECT COUNT(*) FROM ENTREGAS e JOIN ACTIVIDADES a ON a.id_actividad=e.id_actividad " +
            "WHERE a.correo_docente_asignador=? AND e.calificacion IS NULL";
        try(Connection c=MySQL.conectar();PreparedStatement ps=c.prepareStatement(sql)) {
            ps.setString(1,correo);try(ResultSet rs=ps.executeQuery()){return rs.next()?rs.getInt(1):0;}
        }catch(SQLException e){System.err.println("Pendientes docente: "+e.getMessage());return 0;}
    }
    public static String correoActivo(){
        return java.util.prefs.Preferences.userNodeForPackage(com.optem.ui.DashboardView.class).get("LAST_ACTIVE_ACCOUNT","");
    }
    public static String claveMateria(Connection c,String materia) throws SQLException {
        if(materia==null||materia.isBlank()||materia.equalsIgnoreCase("General")||materia.equalsIgnoreCase("Nota personal")||materia.equalsIgnoreCase("Recordatorio"))return null;
        try(PreparedStatement p=c.prepareStatement("SELECT clave_materia FROM MATERIAS WHERE clave_materia=? OR nombre_materia=? LIMIT 1")){
            p.setString(1,materia);p.setString(2,materia);try(ResultSet r=p.executeQuery()){return r.next()?r.getString(1):null;}
        }
    }
    public static List<Actividad> actividades(String correo) {
        List<Actividad> list=new ArrayList<>();if(correo==null||correo.isBlank())return list;
        String sql="SELECT a.id_actividad,a.titulo,a.tipo,a.descripcion,a.fecha,a.hora_vencimiento,a.estado,COALESCE(m.nombre_materia,'General') materia FROM ACTIVIDADES a LEFT JOIN MATERIAS m ON m.clave_materia=a.clave_materia WHERE a.correo_usuario=? ORDER BY a.fecha,a.hora_vencimiento";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,correo);try(ResultSet r=p.executeQuery()){while(r.next()){
                java.sql.Date d=r.getDate("fecha");Time t=r.getTime("hora_vencimiento");
                Actividad a=new Actividad(r.getString("id_actividad"),r.getString("titulo"),r.getString("tipo"),Objects.toString(r.getString("descripcion"),""),d==null?null:d.toLocalDate(),t==null?null:t.toLocalTime(),r.getString("materia"));
                a.setEstado(normalizarEstado(r.getString("estado")));list.add(a);
            }}
        }catch(SQLException e){throw new IllegalStateException("Error al cargar actividades: "+e.getMessage(),e);}
        return list;
    }
    public static void incrementarXp(String correo,int cantidad){
        if(correo==null || correo.isBlank() || cantidad<=0)return;
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("UPDATE USUARIOS SET xp_total=xp_total+? WHERE correo=?")) {
            p.setInt(1,cantidad);p.setString(2,correo);p.executeUpdate();
        }catch(SQLException e){throw new IllegalStateException("No se actualizó la experiencia: "+e.getMessage(),e);}
    }

    public static String normalizarEstado(String estado) {
        if(estado==null)return "PENDIENTE";
        return switch(estado.toLowerCase(Locale.ROOT)){case "completada","completado","entregada","entregado"->"COMPLETADO";case "en_progreso","en_proceso"->"EN_PROCESO";default->"PENDIENTE";};
    }
    public static void insertarActividad(String correo, Actividad a) {
        String sql="INSERT INTO ACTIVIDADES(correo_usuario,clave_materia,id_categoria,titulo,tipo,descripcion,fecha,hora_vencimiento,estado) VALUES(?,?,(SELECT id_categoria FROM CATEGORIAS_ACTIVIDAD WHERE nombre_categoria=? LIMIT 1),?,?,?,?,?,?)";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,correo);p.setString(2,claveMateria(c,a.getMateria()));p.setString(3,a.getTipo());p.setString(4,a.getNombre());p.setString(5,a.getTipo());p.setString(6,a.getDescripcion());
            if(a.getFecha()==null)p.setNull(7,Types.DATE);else p.setDate(7,java.sql.Date.valueOf(a.getFecha()));
            if(a.getHoraVencimiento()==null)p.setNull(8,Types.TIME);else p.setTime(8,Time.valueOf(a.getHoraVencimiento()));
            p.setString(9,estadoBD(a.getEstado()));p.executeUpdate();
        }catch(SQLException e){throw new IllegalStateException("No se guardó actividad: "+e.getMessage(),e);}
    }
    public static String estadoBD(String s) {return "COMPLETADO".equalsIgnoreCase(s)?"completada":("EN_PROCESO".equalsIgnoreCase(s)?"en_progreso":"pendiente");}
    public static void estadoActividad(String correo,String id,String estado) {
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("UPDATE ACTIVIDADES SET estado=? WHERE id_actividad=? AND correo_usuario=?")){
            p.setString(1,estadoBD(estado));p.setString(2,id);p.setString(3,correo);p.executeUpdate();
        }catch(SQLException e){throw new IllegalStateException("No se actualizó estado: "+e.getMessage(),e);}
    }
    public static boolean borrarActividad(String correo,String id) {
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("DELETE FROM ACTIVIDADES WHERE id_actividad=? AND correo_usuario=?")){
            p.setString(1,id);p.setString(2,correo);return p.executeUpdate()>0;
        }catch(SQLException e){throw new IllegalStateException("No se eliminó actividad: "+e.getMessage(),e);}
    }
    public static boolean editarActividad(String correo,Actividad a) {
        String sql="UPDATE ACTIVIDADES SET titulo=?,tipo=?,descripcion=?,fecha=?,hora_vencimiento=?,clave_materia=? WHERE id_actividad=? AND correo_usuario=?";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,a.getNombre());p.setString(2,a.getTipo());p.setString(3,a.getDescripcion());
            if(a.getFecha()==null)p.setNull(4,Types.DATE);else p.setDate(4,java.sql.Date.valueOf(a.getFecha()));
            if(a.getHoraVencimiento()==null)p.setNull(5,Types.TIME);else p.setTime(5,Time.valueOf(a.getHoraVencimiento()));
            p.setString(6,claveMateria(c,a.getMateria()));p.setString(7,a.getId());p.setString(8,correo);return p.executeUpdate()>0;
        }catch(SQLException e){throw new IllegalStateException("No se editó actividad: "+e.getMessage(),e);}
    }
}
