package com.optem.controllers;

import java.io.Serializable;
import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import com.optem.database.MySQL;
import com.optem.database.OptemRepository;
import com.optem.logic.ActividadManager;

public class NotasController {
    private final String[] coloresKeep={"#E57373","#81C784","#64B5F6","#FFD54F","#BA68C8","#4DB6AC","#FF8A65"};
    private final Map<String,String> mapaColores=new HashMap<>();
    private String correo(){return ActividadManager.getInstance().getUsuarioActual();}
    public static class ApunteDTO implements Serializable {
        private static final long serialVersionUID=1L;
        public String id,titulo,materia,contenido,fecha,colorHex;
        public ApunteDTO(String id,String titulo,String materia,String contenido,String fecha,String colorHex){this.id=id;this.titulo=titulo;this.materia=materia;this.contenido=contenido;this.fecha=fecha;this.colorHex=colorHex;}
    }
    public List<String> getMateriasDisponibles(){
        List<String> lista=new ArrayList<>(List.of("Nota personal","Recordatorio"));
        mapaColores.put("Nota personal","#90A4AE");mapaColores.put("Recordatorio","#FFB300");
        int i=0;for(Map<String,String> m:OptemRepository.materias(correo())){
            String n=m.get("nombre");if(!lista.contains(n))lista.add(n);
            mapaColores.putIfAbsent(n,coloresKeep[i++%coloresKeep.length]);
        }return lista;
    }
    public boolean guardarApunte(String titulo,String materia,String textoHtml){
        if(titulo==null||titulo.isBlank()||materia==null||textoHtml==null||textoHtml.replaceAll("<[^>]*>","").replace("&nbsp;","").trim().isEmpty())return false;
        String sql="INSERT INTO NOTAS(correo_usuario,clave_materia,titulo,contenido,color_hex) VALUES(?,?,?,?,?)";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,correo());p.setString(2,OptemRepository.claveMateria(c,materia));p.setString(3,titulo);p.setString(4,textoHtml);p.setString(5,mapaColores.getOrDefault(materia,"#9E9E9E"));p.executeUpdate();return true;
        }catch(SQLException e){System.err.println("No se guardó nota: "+e.getMessage());return false;}
    }
    public boolean eliminarApunte(String id){
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("DELETE FROM NOTAS WHERE id_nota=? AND correo_usuario=?")){
            p.setString(1,id);p.setString(2,correo());return p.executeUpdate()>0;
        }catch(SQLException e){System.err.println("No se eliminó nota: "+e.getMessage());return false;}
    }
    public List<ApunteDTO> getTodosLosApuntes(){
        List<ApunteDTO> lista=new ArrayList<>();
        String sql="SELECT n.id_nota,n.titulo,COALESCE(m.nombre_materia,'Nota personal'),n.contenido,n.fecha_actualizacion,n.color_hex FROM NOTAS n LEFT JOIN MATERIAS m ON m.clave_materia=n.clave_materia WHERE n.correo_usuario=? ORDER BY n.fecha_actualizacion DESC";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,correo());try(ResultSet r=p.executeQuery()){while(r.next()){
                Timestamp t=r.getTimestamp(5);String fecha=t==null?"":t.toLocalDateTime().format(DateTimeFormatter.ofPattern("dd/MM/yyyy • hh:mm a"));
                lista.add(new ApunteDTO(r.getString(1),r.getString(2),r.getString(3),Objects.toString(r.getString(4),""),fecha,Objects.toString(r.getString(6),"#9E9E9E")));
            }}
        }catch(SQLException e){System.err.println("No se cargaron notas: "+e.getMessage());}
        return lista;
    }
}
