package com.optem.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Conexión centralizada: credenciales mediante variables de entorno, nunca en Git. */
public final class MySQL {
    private MySQL() {}
    public static Connection conectar() throws SQLException {
        String host = System.getenv().getOrDefault("OPTEM_DB_HOST", "100.67.119.35");
        String port = System.getenv().getOrDefault("OPTEM_DB_PORT", "3306");
        String db = System.getenv().getOrDefault("OPTEM_DB_NAME", "optem_db");
        String user = System.getenv("OPTEM_DB_USER");
        String pass = System.getenv("OPTEM_DB_PASSWORD");
        if (user == null || user.isBlank() || pass == null) {
            throw new SQLException("Configura OPTEM_DB_USER y OPTEM_DB_PASSWORD en Windows.");
        }
        return DriverManager.getConnection("jdbc:mysql://"+host+":"+port+"/"+db+"?useUnicode=true&characterEncoding=UTF-8&connectionTimeZone=SERVER&connectTimeout=6000", user, pass);
    }
}
