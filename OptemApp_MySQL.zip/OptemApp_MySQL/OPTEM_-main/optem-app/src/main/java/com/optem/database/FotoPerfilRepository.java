package com.optem.database;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.*;
import javafx.scene.image.Image;
import java.io.ByteArrayInputStream;

/** Profile pictures are stored as actual image bytes in MySQL, not as local disk paths. */
public final class FotoPerfilRepository {
    private static final int MAX_BYTES = 3 * 1024 * 1024;
    private FotoPerfilRepository() {}
    public static void guardar(String correo, File archivo) throws IOException, SQLException {
        if (correo == null || correo.isBlank()) throw new IllegalArgumentException("Falta iniciar sesión.");
        if (archivo == null || !archivo.isFile()) throw new IOException("No se seleccionó ningún archivo.");
        if (archivo.length() > MAX_BYTES) throw new IOException("La foto debe pesar 3 MB o menos.");
        byte[] datos = Files.readAllBytes(archivo.toPath());
        if (datos.length == 0) throw new IOException("El archivo está vacío.");
        Image imagen = new Image(new ByteArrayInputStream(datos), 1, 1, true, true);
        if (imagen.isError() || imagen.getWidth() <= 0) throw new IOException("Selecciona una imagen válida PNG o JPG.");
        String nombre = archivo.getName().toLowerCase(java.util.Locale.ROOT);
        String mime = nombre.endsWith(".png") ? "image/png" : (nombre.endsWith(".jpg") || nombre.endsWith(".jpeg") ? "image/jpeg" : null);
        if (mime == null) throw new IOException("Solo se admiten JPG y PNG.");
        String sql = "INSERT INTO PREFERENCIAS_USUARIO (correo_usuario,foto_perfil,foto_mime) VALUES (?,?,?) " +
                "ON DUPLICATE KEY UPDATE foto_perfil=VALUES(foto_perfil),foto_mime=VALUES(foto_mime)";
        try (Connection c=MySQL.conectar(); PreparedStatement ps=c.prepareStatement(sql)) {
            ps.setString(1, correo); ps.setBytes(2, datos); ps.setString(3, mime);
            if(ps.executeUpdate()==0) throw new SQLException("No se guardó la foto.");
        }
    }
    public static Image cargar(String correo) {
        if (correo==null || correo.isBlank()) return null;
        try (Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT foto_perfil FROM PREFERENCIAS_USUARIO WHERE correo_usuario=?")) {
            p.setString(1, correo);
            try(ResultSet r=p.executeQuery()) {
                if(r.next()) {
                    byte[] data=r.getBytes(1);
                    if(data!=null && data.length>0) {
                        Image img=new Image(new ByteArrayInputStream(data));
                        return img.isError()?null:img;
                    }
                }
            }
        } catch (SQLException ex) { System.err.println("No se cargó la foto de MySQL: " + ex.getMessage()); }
        return null;
    }
}
