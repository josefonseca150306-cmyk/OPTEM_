package com.optem.controllers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.prefs.Preferences;
import java.util.stream.Collectors;

import com.optem.logic.ActividadManager;
import com.optem.models.Actividad;
import com.optem.ui.DashboardView;

public class ChatBotController {

    private final ActividadManager actividadManager = ActividadManager.getInstance();
    private final Preferences prefs = Preferences.userNodeForPackage(DashboardView.class);
    private final String correoActual;
    private final String rolUsuario;
    private final String nombreUsuario;

    public ChatBotController() {
        this.correoActual = prefs.get("LAST_ACTIVE_ACCOUNT", "");
        this.rolUsuario = prefs.get("ROLE_" + correoActual, "ESTUDIANTE");
        this.nombreUsuario = prefs.get("NAME_" + correoActual, "Usuario").split(" ")[0];
    }

    public String procesarMensaje(String mensaje) {
        // Always resolve the account/role at message time; never cache it across role changes.
        String actual = prefs.get("LAST_ACTIVE_ACCOUNT", "");
        String rolUsuario = prefs.get("ROLE_" + actual, "ESTUDIANTE");
        String nombreUsuario = prefs.get("NAME_" + actual, "Usuario").split(" ")[0];
        actividadManager.setUsuarioActual(actual);
        if(mensaje == null || mensaje.isBlank()) return "Escribe una consulta para ayudarte.";
        String input = mensaje.toLowerCase().trim()
                .replace("á", "a").replace("é", "e").replace("í", "i")
                .replace("ó", "o").replace("ú", "u").replace("?", "").replace("¿", "");

        if (input.matches(".*\\b(hola|buenos dias|buenas tardes|buenas noches|que tal|saludos)\\b.*")) {
            return "¡Hola, " + nombreUsuario + "! Soy Optem AI 🤖. Estoy aquí para organizar tu vida universitaria. ¿En qué te ayudo hoy?";
        }
        if (input.matches(".*\\b(gracias|muchas gracias|te lo agradezco|ok|vale|perfecto)\\b.*")) {
            return "¡De nada, " + nombreUsuario + "! Aquí estoy para ayudarte a ser más productivo. 🚀 Si necesitas algo más, dímelo.";
        }
        if (input.matches(".*\\b(quien eres|que eres|como te llamas|para que sirves)\\b.*")) {
            return "Soy Optem AI, tu copiloto inteligente integrado en el ERP. Fui creado por el equipo de desarrollo de Ingeniería en Software para ayudarte a gestionar tus tareas, agenda y reuniones. 🧠";
        }
        if (input.matches(".*\\b(estoy aburrido|cuentame un chiste|dime algo)\\b.*")) {
            return "¡La universidad puede ser estresante! Aquí va un chiste: ¿Por qué los programadores prefieren el modo oscuro? Porque la luz atrae a los bugs. 🐛😂 ¿Volvemos al trabajo?";
        }
        if (input.matches(".*\\b(como estas|que haces|como te va)\\b.*")) {
            return "¡Procesando datos a la velocidad de la luz! ⚡ Todo en el sistema está estable. ¿Y tú, " + nombreUsuario + "? ¿Listo para ser productivo?";
        }
        if (input.matches(".*\\b(adios|bye|nos vemos|hasta luego|chao)\\b.*")) {
            return "¡Hasta luego, " + nombreUsuario + "! Recuerda que estaré flotando aquí en la esquina si me necesitas. 👋";
        }

        if (rolUsuario.equals("ESTUDIANTE")) {
            
            if (input.matches(".*\\b(tareas|tarea|pendientes|trabajos|entregas)\\b.*")) {
                List<Actividad> pendientes = actividadManager.getAllActividades().stream()
                        .filter(a -> "PENDIENTE".equals(a.getEstado()) && a.getTipo() != null && a.getTipo().equals("Tarea"))
                        .collect(Collectors.toList());
                
                if (pendientes.isEmpty()) {
                    return "¡Buenas noticias! Revisé tu base de datos y no tienes tareas pendientes para los próximos días. ¡Disfruta tu tiempo libre! 🎉";
                }
                StringBuilder sb = new StringBuilder("Revisé tu sistema y tienes estas tareas próximas:\n");
                for (Actividad act : pendientes) {
                    sb.append("• ").append(act.getNombre()).append(" (Vence el ").append(act.getFecha()).append(")\n");
                }
                sb.append("\nTe sugiero ir a la pestaña 'Tareas' para empezar a trabajar en ellas.");
                return sb.toString();
            }

            if (input.matches(".*\\b(actividades|actividad|agenda|eventos|planes|horario)\\b.*")) {
                List<Actividad> hoy = actividadManager.getActividadesDelDia(LocalDate.now());
                if (hoy.isEmpty()) {
                    return "Tu agenda para hoy (" + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + ") está completamente libre. 📅 ¡Aprovecha para descansar o adelantar proyectos!";
                }
                StringBuilder sb = new StringBuilder("Para hoy tienes programado:\n");
                for(Actividad act : hoy) {
                    sb.append("- ").append(act.getNombre()).append(" a las ").append(act.getHoraVencimiento()).append("\n");
                }
                return sb.toString();
            }

            if (input.matches(".*\\b(reuniones|reunion|clases en linea|videollamadas|teams|meet|zoom|llamada)\\b.*")) {
                return "En Reuniones puedes abrir una videollamada de Jitsi o entrar a la sala de una materia. El navegador pedirá permiso de cámara y micrófono; copia el enlace para invitar a otros.";
            }

            if (input.matches(".*\\b(caducada|atrasada|vencida|olvide una tarea|no entregue)\\b.*")) {
                return "Consulta el estado y fecha de la tarea en el Tablero. Una actividad vencida no implica automáticamente que exista una penalización de XP.";
            }

            if (input.matches(".*\\b(ayudame a estudiar|estudiar|explicame|no entiendo|ayuda|duda)\\b.*")) {
                return "¡Claro que sí! Como tu copiloto de Ingeniería en Software, te sugiero crear un apunte nuevo en tu 'Cuaderno de Notas'. Luego, abre el 'Reloj Pomodoro', ponlo en 25 minutos y concéntrate en un solo concepto. Si necesitas que te explique un tema de programación en específico (como Java, SQL o Redes), dímelo aquí. 🧠";
            }
            
            if (input.matches(".*\\b(logros|xp|nivel|puntos|medallas)\\b.*")) {
                return "Recuerda que ganas XP por cada tarea entregada a tiempo y por cada sesión Pomodoro completada sin interrupciones. Ve a la pestaña 'Logros' para ver qué medallas has desbloqueado. 🏆";
            }
        }
        
        else if (rolUsuario.equals("MAESTRO")) {
            
            if (input.matches(".*\\b(entregaron|entregas|revisar tareas|alumnos)\\b.*")) {
                return "Abre el Gestor de Evaluaciones para revisar las entregas registradas en MySQL y asignar calificaciones.";
            }
            
            if (input.matches(".*\\b(calificaciones|desempeño|promedio|repasar)\\b.*")) {
                return "Las calificaciones se almacenan en ENTREGAS. Usa el panel del docente para consultarlas; no inventaré promedios de alumnos.";
            }

            if (input.matches(".*\\b(recomendar tarea|dejar tarea|que tarea dejo|actividad nueva)\\b.*")) {
                return "Basado en tu temario actual, te sugiero asignar un 'Mapa Mental' sobre el último tema visto en clase. Toma poco tiempo calificarlo y les ayuda a retener la información. Puedes crearlo rápido desde tu Tablero Kanban. 💡";
            }
        }
        
        else if (rolUsuario.equals("ADMINISTRADOR")) {
            
            if (input.matches(".*\\b(error|traba|caido|lento|bug|falla|estado del sistema)\\b.*")) {
                return "OPTEM utiliza MySQL en Ubuntu Server mediante Tailscale. No hay diagnóstico automático completo disponible desde este chat; revisa la consola para conocer errores concretos.";
            }
            
            if (input.matches(".*\\b(uso|impacto|estadisticas|metricas|app)\\b.*")) {
                return "Las estadísticas deben obtenerse de las tablas reales de MySQL. Este chatbot aún no dispone de un reporte histórico calculado.";
            }
            
            if (input.matches(".*\\b(desempeño maestro|evaluar|profesores|docentes)\\b.*")) {
                return "Todavía no hay datos suficientes para evaluar el desempeño docente. No se deben inventar índices de asistencia o puntualidad.";
            }
        }

        return "Comprendo lo que mencionas, pero mi base de datos aún no tiene una respuesta programada para eso. Como tu Optem AI, te sugiero usar palabras clave como 'tareas', 'actividades', 'agenda', 'reuniones', 'estudiar' o 'errores' para poder ayudarte mejor. 🤔";
    }
}