package com.optem.controllers;

import java.time.LocalDate;

import com.optem.logic.ActividadManager;
import com.optem.database.MySQL;
import java.sql.*;

public class LogrosController {

    public long getActividadesHechasHoy() {
        return ActividadManager.getInstance().getActividadesDelDia(LocalDate.now())
                .stream()
                .filter(a -> a.getEstado().equals("COMPLETADO"))
                .count();
    }
    
    public long getActividadesPendientes() {
        return ActividadManager.getInstance().getAllActividades()
                .stream()
                .filter(a -> a.getEstado().equals("PENDIENTE"))
                .count();
    }

    public long getTotalActividadesHoy() {
        return ActividadManager.getInstance().getActividadesDelDia(LocalDate.now()).size();
    }

    public int calcularXpActual() {
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT xp_total FROM USUARIOS WHERE correo=?")) {
            p.setString(1,ActividadManager.getInstance().getUsuarioActual());
            try(ResultSet r=p.executeQuery()){return r.next()?r.getInt(1):0;}
        }catch(SQLException e){System.err.println("XP MySQL: "+e.getMessage());return 0;}
    }

    public int calcularXpMeta() {
        long totales = getTotalActividadesHoy();
        return totales == 0 ? 100 : (int) totales * 100;
    }

    public int calcularDiasRacha(int xpActual, int xpMeta) {
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT racha_dias FROM USUARIOS WHERE correo=?")) {
            p.setString(1,ActividadManager.getInstance().getUsuarioActual());
            try(ResultSet r=p.executeQuery()){return r.next()?r.getInt(1):0;}
        }catch(SQLException e){return 0;}
    }

    public double calcularBonoRacha(int diasRacha) {
        if (diasRacha >= 5) return 1.5;
        if (diasRacha >= 3) return 1.2;
        return 1.0; 
    }

    public String obtenerNivelActual(int xpActual) {
        if (xpActual >= 600) return "Experto";
        if (xpActual >= 300) return "Avanzado";
        if (xpActual >= 100) return "Intermedio";
        return "Novato";
    }
    
    public boolean tieneMedallaPrimeraSangre() {
        return getActividadesHechasHoy() >= 1;
    }
    
    public boolean tieneMedallaImparable() {
        return getActividadesHechasHoy() >= 3;
    }
    
    public boolean tieneMedallaSobreviviente() {
        return getActividadesPendientes() >= 5;
    }
}