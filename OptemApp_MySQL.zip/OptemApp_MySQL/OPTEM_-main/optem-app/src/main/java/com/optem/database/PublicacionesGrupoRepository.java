package com.optem.database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Publicaciones del canal General compartidas entre integrantes reales del grupo. */
public final class PublicacionesGrupoRepository {
    private PublicacionesGrupoRepository() { }

    public record Publicacion(long id, String autor, String texto, String fecha) { }

    private static boolean autorizado(Connection c, int idGrupo, String correo) throws SQLException {
        String sql = "SELECT 1 FROM GRUPOS g JOIN USUARIOS u ON u.correo=? " +
            "WHERE g.id_grupo=? AND (g.correo_docente=u.correo OR EXISTS (" +
            "SELECT 1 FROM CARGA_ACADEMICA ca WHERE ca.id_grupo=g.id_grupo " +
            "AND ca.correo_estudiante=u.correo AND ca.estado_inscripcion='inscrito'))";
        try (PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, correo); p.setInt(2, idGrupo);
            try (ResultSet r = p.executeQuery()) { return r.next(); }
        }
    }

    public static List<Publicacion> listar(int grupo, String lector) throws SQLException {
        List<Publicacion> publicaciones = new ArrayList<>();
        try (Connection c = MySQL.conectar()) {
            if (!autorizado(c, grupo, lector)) throw new SQLException("No perteneces a este grupo.");
            String sql = "SELECT pg.id_publicacion, CONCAT_WS(' ',u.nombre,u.apellidos) autor, " +
                "pg.contenido, DATE_FORMAT(pg.fecha_creacion,'%d/%m/%Y %H:%i') fecha " +
                "FROM PUBLICACIONES_GRUPO pg JOIN USUARIOS u ON u.correo=pg.correo_autor " +
                "WHERE pg.id_grupo=? ORDER BY pg.fecha_creacion,pg.id_publicacion";
            try (PreparedStatement p = c.prepareStatement(sql)) {
                p.setInt(1, grupo);
                try (ResultSet r = p.executeQuery()) {
                    while (r.next()) publicaciones.add(new Publicacion(r.getLong(1),r.getString(2),r.getString(3),r.getString(4)));
                }
            }
        }
        return publicaciones;
    }

    public static void publicar(int grupo, String correo, String texto) throws SQLException {
        if (correo == null || correo.isBlank() || texto == null || texto.isBlank() || texto.length() > 5000)
            throw new SQLException("La publicación debe tener entre 1 y 5000 caracteres.");
        try (Connection c = MySQL.conectar()) {
            if (!autorizado(c, grupo, correo)) throw new SQLException("No perteneces a este grupo.");
            try (PreparedStatement p = c.prepareStatement(
                "INSERT INTO PUBLICACIONES_GRUPO(id_grupo,correo_autor,contenido) VALUES(?,?,?)")) {
                p.setInt(1,grupo);p.setString(2,correo);p.setString(3,texto.trim());p.executeUpdate();
            }
        }
    }
}
