package com.optem.database;

import java.sql.*;
import java.util.*;
import java.util.prefs.Preferences;
import com.optem.ui.DashboardView;

public final class UsuariosRepository {
    private UsuariosRepository(){}
    private static String usuario(){return Preferences.userNodeForPackage(DashboardView.class).get("LAST_ACTIVE_ACCOUNT", "");}
    public static List<Map<String,String>> listarUsuarios(String filtro,String rol){
        List<Map<String,String>> lista=new ArrayList<>();
        String sql="SELECT u.correo,CONCAT_WS(' ',u.nombre,u.apellidos),u.numero_cuenta,r.nombre_rol " +
           "FROM USUARIOS u JOIN ROLES r ON r.id_rol=u.id_rol WHERE " +
           "(LOWER(CONCAT_WS(' ',u.nombre,u.apellidos)) LIKE ? OR LOWER(u.correo) LIKE ? OR u.numero_cuenta LIKE ?) " +
           "AND (?='Todos los Roles' OR (?='Estudiantes' AND r.nombre_rol='Estudiante') " +
           "OR (?='Maestros' AND r.nombre_rol='Docente') OR (?='Administradores' AND r.nombre_rol='Administrador')) " +
           "ORDER BY u.nombre LIMIT 100";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)) {
            String t="%"+(filtro==null?"":filtro.trim().toLowerCase(Locale.ROOT))+"%";
            for(int i=1;i<=3;i++)p.setString(i,t);
            for(int i=4;i<=7;i++)p.setString(i,rol==null?"Todos los Roles":rol);
            try(ResultSet r=p.executeQuery()){while(r.next()){
                Map<String,String> u=new HashMap<>();u.put("correo",r.getString(1));u.put("nombre",r.getString(2));
                u.put("cuenta",r.getString(3));u.put("rol",r.getString(4));lista.add(u);
            }}
        }catch(SQLException ex){System.err.println("Usuarios MySQL: "+ex.getMessage());}
        return lista;
    }
    public static void crearAlumno(String email,String numero,String nombre,String apellidos) throws SQLException {
        if(!email.matches("^[^@ ]+@(?:alumno[.]uaemex[.]mx|uaemex[.]mx)$") || !numero.matches("[0-9]{7}") || nombre.isBlank() || apellidos.isBlank())
            throw new SQLException("Correo, matrícula o nombre inválido.");
        try(Connection c=MySQL.conectar()){
            c.setAutoCommit(false);
            try {
                try(PreparedStatement ps=c.prepareStatement("SELECT 1 FROM USUARIOS u JOIN ROLES r ON u.id_rol=r.id_rol WHERE u.correo=? AND r.nombre_rol='Administrador'")){
                    ps.setString(1,usuario());try(ResultSet rs=ps.executeQuery()){
                        if(!rs.next())throw new SQLException("Solo el administrador puede crear usuarios.");
                    }
                }
                try(PreparedStatement ps=c.prepareStatement("INSERT INTO USUARIOS(correo,numero_cuenta,nombre,apellidos,carrera,id_rol) " +
                    "VALUES(?,?,?,?,'Ingeniería de Software',(SELECT id_rol FROM ROLES WHERE nombre_rol='Estudiante'))")){
                    ps.setString(1,email);ps.setString(2,numero);ps.setString(3,nombre.trim());ps.setString(4,apellidos.trim());ps.executeUpdate();
                }
                try(PreparedStatement ps=c.prepareStatement("INSERT INTO PREFERENCIAS_USUARIO(correo_usuario) VALUES(?)")){
                    ps.setString(1,email);ps.executeUpdate();
                }
                c.commit();
            }catch(SQLException e){c.rollback();throw e;}finally{c.setAutoCommit(true);}
        }
    }
}
