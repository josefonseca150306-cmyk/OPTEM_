package com.optem.controllers;

import java.util.prefs.Preferences;
 
import com.optem.database.OptemRepository;
import com.optem.ui.DashboardView;

import javafx.scene.control.Label;
import javafx.stage.Stage;

public class LoginController {

    public boolean checkAutoLogin(Stage stage) {
        Preferences prefsDirect = Preferences.userNodeForPackage(DashboardView.class);
        
        if (prefsDirect.get("ACCOUNTS_LIST", "").isEmpty()) {
            try {
                prefsDirect.clear();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        String lastActive = prefsDirect.get("LAST_ACTIVE_ACCOUNT", "");
        if (!lastActive.isEmpty() && OptemRepository.existeUsuario(lastActive)) {
            new DashboardView().show(stage, lastActive, "");
            return true; 
        }
        return false;
    }

    public void handleLogin(String nombre, String apellido, String correo, String password, String rol, Label lblError, Stage stage) {
        
        if (correo.isEmpty()) { 
            lblError.setText("Por favor ingresa tu correo institucional."); 
            lblError.setVisible(true); 
            return; 
        }

        if (!rol.equals("ADMINISTRADOR") && nombre.isEmpty()) { 
            lblError.setText("Por favor ingresa tu nombre."); 
            lblError.setVisible(true); 
            return; 
        }
        
        if (!password.matches("\\d{7}")) { 
            lblError.setText("Cuenta incorrecta. Debe contener exactamente 7 números."); 
            lblError.setVisible(true); 
            return; 
        }
        
        if (!correo.contains("@")) { 
            if (correo.matches("\\d+")) {
                correo += "@alumno.uaemex.mx"; 
            } else {
                correo += "@uaemex.mx"; 
            }
        }

        java.util.Map<String,String> usuario;
        try { usuario = OptemRepository.autenticar(correo, password, rol); }
        catch (IllegalStateException e) {
            lblError.setText("Error de MySQL: " + e.getMessage()); lblError.setVisible(true); return;
        }
        boolean accesoConcedido = usuario != null;

        if (accesoConcedido) {
            lblError.setVisible(false);

            Preferences prefs = Preferences.userNodeForPackage(DashboardView.class);
            
            String nombreCompleto = usuario.get("nombre") + " " + usuario.get("apellidos");
            
            prefs.put("NAME_" + correo, nombreCompleto);
            prefs.put("ROLE_" + correo, rol); 
            prefs.put("LAST_ACTIVE_ACCOUNT", correo);

            DashboardView dashboard = new DashboardView();
            dashboard.show(stage, correo, "");
            
        } else {
            lblError.setText("❌ Correo o número de cuenta incorrectos."); 
            lblError.setVisible(true); 
        }
    }
}