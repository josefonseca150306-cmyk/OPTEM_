package com.optem.database;

import java.awt.Desktop;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.net.URI;
import java.sql.*;
import java.util.UUID;

/** Stable video-room links stored in MySQL; actual A/V is provided by the browser. */
public final class ReunionesRepository {
    private ReunionesRepository() {}
    public static String salaDeGrupo(int grupo, String titulo) throws SQLException {
        if (grupo <= 0) throw new SQLException("Grupo inválido.");
        try(Connection c=MySQL.conectar()) {
            c.setAutoCommit(false);
            try {
                // Stable one-room-per-group; lock group to avoid concurrent duplicate rooms.
                try(PreparedStatement lock=c.prepareStatement("SELECT id_grupo FROM GRUPOS WHERE id_grupo=? FOR UPDATE")) {
                    lock.setInt(1,grupo);try(ResultSet r=lock.executeQuery()){if(!r.next())throw new SQLException("Grupo no registrado.");}
                }
                try(PreparedStatement p=c.prepareStatement("SELECT enlace FROM REUNIONES WHERE id_grupo=? LIMIT 1")) {
                    p.setInt(1,grupo);
                    try(ResultSet r=p.executeQuery()){if(r.next()) {String url=r.getString(1);c.commit();return url;}}
                }
                String url=nuevoEnlace();
                try(PreparedStatement p=c.prepareStatement("INSERT INTO REUNIONES(id_grupo,titulo,enlace,creado_por) VALUES(?,?,?,?)")) {
                    p.setInt(1,grupo);p.setString(2,titulo);p.setString(3,url);p.setString(4,usuario());p.executeUpdate();
                }
                c.commit();return url;
            } catch(SQLException e){c.rollback();throw e;}finally{c.setAutoCommit(true);}
        }
    }
    public static String nuevaSala(String titulo) throws SQLException {
        if(titulo==null || titulo.isBlank()) throw new SQLException("Escribe un nombre de reunión.");
        String url=nuevoEnlace();
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("INSERT INTO REUNIONES(titulo,enlace,creado_por) VALUES(?,?,?)")) {
            p.setString(1,titulo.trim());p.setString(2,url);p.setString(3,usuario());p.executeUpdate();
        }
        return url;
    }
    private static String usuario() {
        return java.util.prefs.Preferences.userNodeForPackage(com.optem.ui.DashboardView.class).get("LAST_ACTIVE_ACCOUNT","");
    }
    private static String nuevoEnlace() {
        return "https://meet.jit.si/OPTEM-" + UUID.randomUUID().toString().replace("-", "");
    }
    public static void abrirEnNavegador(String url) throws Exception {
        URI uri=URI.create(url);
        if(!"https".equalsIgnoreCase(uri.getScheme()) || !"meet.jit.si".equalsIgnoreCase(uri.getHost()))
            throw new IllegalArgumentException("Enlace de reunión no permitido.");
        if(!Desktop.isDesktopSupported() || !Desktop.getDesktop().isSupported(Desktop.Action.BROWSE))
            throw new IllegalStateException("Este equipo no permite abrir el navegador automáticamente.");
        Desktop.getDesktop().browse(uri);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(url), null);
    }
}
