package com.optem.database;

import java.io.File;
import java.nio.file.Files;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.prefs.Preferences;
import com.optem.ui.DashboardView;

public final class EntregasRepository {
    private EntregasRepository(){}
    private static String usuario(){return Preferences.userNodeForPackage(DashboardView.class).get("LAST_ACTIVE_ACCOUNT","");}
    private static final long MAX_FILE=5L*1024*1024;

    public static class Entrega {
        public int id; public String estudiante,nombre,archivoNombre,estado,feedback;
        public Double calificacion;
    }
    public static Entrega deActividad(String actividad) {
        String q="SELECT e.id_entrega,e.archivo_nombre,e.calificacion,e.retroalimentacion,e.estado FROM ENTREGAS e " +
                 "WHERE e.id_actividad=? AND e.correo_estudiante=? ORDER BY e.numero_intento DESC LIMIT 1";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(q)) {
            p.setString(1,actividad);p.setString(2,usuario());
            try(ResultSet r=p.executeQuery()) {
                if(!r.next())return null;
                Entrega e=new Entrega();e.id=r.getInt(1);e.archivoNombre=r.getString(2);
                double cal=r.getDouble(3);e.calificacion=r.wasNull()?null:cal/10.0;
                e.feedback=r.getString(4);e.estado=r.getString(5);return e;
            }
        }catch(SQLException ex){throw new IllegalStateException("Consulta de entrega: "+ex.getMessage(),ex);}
    }
    public static void entregar(String actividad,File archivo) throws Exception {
        if(archivo!=null && (!archivo.isFile() || archivo.length()>MAX_FILE))throw new IllegalArgumentException("Selecciona un archivo de 5 MB o menos.");
        byte[] data=archivo==null?null:Files.readAllBytes(archivo.toPath());
        String current=usuario();
        try(Connection c=MySQL.conectar()){
            c.setAutoCommit(false);
            try {
                try(PreparedStatement ok=c.prepareStatement("SELECT id_actividad FROM ACTIVIDADES WHERE id_actividad=? AND correo_usuario=? FOR UPDATE")) {
                    ok.setString(1,actividad);ok.setString(2,current);
                    try(ResultSet r=ok.executeQuery()){if(!r.next())throw new SQLException("Esta tarea no pertenece a tu cuenta.");}
                }
                try(PreparedStatement check=c.prepareStatement("SELECT calificacion FROM ENTREGAS WHERE id_actividad=? AND correo_estudiante=? AND numero_intento=1")) {
                    check.setString(1,actividad);check.setString(2,current);
                    try(ResultSet r=check.executeQuery()) {if(r.next() && r.getObject(1)!=null)throw new SQLException("Esta entrega ya fue calificada.");}
                }
                String sql="INSERT INTO ENTREGAS(id_actividad,correo_estudiante,numero_intento,archivo_nombre,archivo_datos,archivo_tipo,texto_entrega,estado) " +
                  "VALUES(?,?,1,?,?,?,?, 'entregada') ON DUPLICATE KEY UPDATE archivo_nombre=VALUES(archivo_nombre),archivo_datos=VALUES(archivo_datos), " +
                  "archivo_tipo=VALUES(archivo_tipo),texto_entrega=VALUES(texto_entrega),fecha_entrega=CURRENT_TIMESTAMP,estado='entregada'";
                try(PreparedStatement p=c.prepareStatement(sql)){
                    p.setString(1,actividad);p.setString(2,current);p.setString(3,archivo==null?null:archivo.getName());
                    if(data==null)p.setNull(4,Types.LONGVARBINARY);else p.setBytes(4,data);
                    p.setString(5,archivo==null?null:Files.probeContentType(archivo.toPath()));
                    p.setString(6,archivo==null?"Entrega desde OPTEM sin archivo adjunto.":"Entrega desde OPTEM con archivo.");p.executeUpdate();
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE ACTIVIDADES SET estado='completada' WHERE id_actividad=? AND correo_usuario=?")) {
                    p.setString(1,actividad);p.setString(2,current);p.executeUpdate();
                }
                c.commit();
            }catch(Exception e){c.rollback();throw e;}finally{c.setAutoCommit(true);}
        }
    }
    public static List<Map<String,String>> tareasDocente(boolean calificadas) {
        List<Map<String,String>> result=new ArrayList<>();
        String q="SELECT a.titulo,m.nombre_materia,MAX(a.fecha) fecha,COUNT(DISTINCT a.id_actividad) total," +
                 "COUNT(DISTINCT e.id_entrega) entregados,COUNT(DISTINCT CASE WHEN e.calificacion IS NOT NULL THEN e.id_entrega END) calificadas " +
                 "FROM ACTIVIDADES a JOIN MATERIAS m ON m.clave_materia=a.clave_materia " +
                 "LEFT JOIN ENTREGAS e ON e.id_actividad=a.id_actividad " +
                 "WHERE a.correo_docente_asignador=? GROUP BY a.titulo,m.nombre_materia ORDER BY fecha DESC";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(q)){
            p.setString(1,usuario());try(ResultSet r=p.executeQuery()){while(r.next()){
                boolean completa=r.getInt("total")>0 && r.getInt("total")==r.getInt("calificadas");
                if(completa!=calificadas)continue;
                Map<String,String> m=new HashMap<>();m.put("titulo",r.getString(1));m.put("materia",r.getString(2));
                m.put("fecha",Objects.toString(r.getString(3),"Sin fecha"));m.put("total",r.getString(4));m.put("entregados",r.getString(5));result.add(m);
            }}
        }catch(SQLException e){System.err.println("Tareas de docente: "+e.getMessage());}
        return result;
    }
    public static List<Entrega> entregasDocente(String titulo,String materia) {
        List<Entrega> out=new ArrayList<>();
        String q="SELECT u.correo,CONCAT_WS(' ',u.nombre,u.apellidos) estudiante,e.id_entrega,e.archivo_nombre,e.calificacion,e.estado,e.retroalimentacion " +
             "FROM ACTIVIDADES a JOIN USUARIOS u ON u.correo=a.correo_usuario JOIN MATERIAS m ON m.clave_materia=a.clave_materia " +
             "LEFT JOIN ENTREGAS e ON e.id_actividad=a.id_actividad AND e.correo_estudiante=u.correo " +
             "WHERE a.correo_docente_asignador=? AND a.titulo=? AND m.nombre_materia=? ORDER BY u.nombre";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(q)) {
            p.setString(1,usuario());p.setString(2,titulo);p.setString(3,materia);
            try(ResultSet r=p.executeQuery()){while(r.next()){
                Entrega e=new Entrega();e.estudiante=r.getString(1);e.nombre=r.getString(2);e.id=r.getInt(3);
                e.archivoNombre=r.getString(4);double cal=r.getDouble(5);e.calificacion=r.wasNull()?null:cal/10.0;
                e.estado=r.getString(6);e.feedback=r.getString(7);out.add(e);
            }}
        }catch(SQLException ex){System.err.println("Entregas del docente: "+ex.getMessage());}
        return out;
    }
    public static boolean calificar(int entregaId,double nota,String feedback) {
        if(entregaId<=0 || !Double.isFinite(nota) || nota<0 || nota>10)return false;
        try(Connection c=MySQL.conectar()) {
            c.setAutoCommit(false);
            try {
                String estudiante;
                boolean yaCalificada;
                String q="SELECT e.correo_estudiante,e.calificacion FROM ENTREGAS e " +
                     "JOIN ACTIVIDADES a ON a.id_actividad=e.id_actividad WHERE e.id_entrega=? AND a.correo_docente_asignador=? FOR UPDATE";
                try(PreparedStatement p=c.prepareStatement(q)){p.setInt(1,entregaId);p.setString(2,usuario());
                    try(ResultSet r=p.executeQuery()){
                        if(!r.next())throw new SQLException("La entrega no pertenece a tus grupos.");
                        estudiante=r.getString(1);yaCalificada=r.getObject(2)!=null;
                    }
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE ENTREGAS SET calificacion=?,retroalimentacion=?,estado='calificada' WHERE id_entrega=?")){
                    p.setDouble(1,nota*10);p.setString(2,feedback);p.setInt(3,entregaId);p.executeUpdate();
                }
                if(!yaCalificada) {
                    try(PreparedStatement p=c.prepareStatement("UPDATE USUARIOS SET xp_total=xp_total+15 WHERE correo=?")){
                        p.setString(1,estudiante);p.executeUpdate();
                    }
                }
                c.commit();return true;
            }catch(SQLException e){c.rollback();System.err.println("Calificación: "+e.getMessage());return false;}
            finally{c.setAutoCommit(true);}
        }catch(SQLException e){System.err.println("Calificación: "+e.getMessage());return false;}
    }
    public static void descargarAdjunto(int id,File destino) throws Exception {
        if(id<=0 || destino==null)throw new IllegalArgumentException("Entrega inválida.");
        String q="SELECT e.archivo_datos FROM ENTREGAS e JOIN ACTIVIDADES a ON a.id_actividad=e.id_actividad " +
            "WHERE e.id_entrega=? AND a.correo_docente_asignador=?";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(q)){
            p.setInt(1,id);p.setString(2,usuario());try(ResultSet r=p.executeQuery()){
                if(!r.next() || r.getBytes(1)==null)throw new SQLException("Archivo no disponible.");
                Files.write(destino.toPath(),r.getBytes(1));
            }
        }
    }
    public static boolean asignarGrupo(int idGrupo,String titulo,String descripcion,LocalDate fecha) {
        if(idGrupo<=0 || titulo==null || titulo.isBlank() || fecha==null)return false;
        String sql="INSERT INTO ACTIVIDADES(correo_usuario,clave_materia,id_categoria,correo_docente_asignador,titulo,tipo,descripcion,fecha,hora_vencimiento,estado) " +
             "SELECT ca.correo_estudiante,g.clave_materia,(SELECT id_categoria FROM CATEGORIAS_ACTIVIDAD WHERE nombre_categoria='Tarea')," +
             "g.correo_docente,?,'Tarea',?,?, '23:59:00','pendiente' FROM CARGA_ACADEMICA ca " +
             "JOIN GRUPOS g ON ca.id_grupo=g.id_grupo WHERE g.id_grupo=? AND g.correo_docente=? AND ca.estado_inscripcion='inscrito'";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,titulo.trim());p.setString(2,descripcion);p.setDate(3,java.sql.Date.valueOf(fecha));
            p.setInt(4,idGrupo);p.setString(5,usuario());return p.executeUpdate()>0;
        }catch(SQLException e){System.err.println("No se asignó tarea: "+e.getMessage());return false;}
    }
}
