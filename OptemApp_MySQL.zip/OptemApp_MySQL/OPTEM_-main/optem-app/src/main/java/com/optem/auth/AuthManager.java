package com.optem.auth;

import java.util.HashMap;
import java.util.Map;
import com.optem.database.OptemRepository;

public class AuthManager {
    public Map<String,String> iniciarSesion(String correo,String numCuenta){
        Map<String,String> m=new HashMap<>();
        try {
            Map<String,String> u=OptemRepository.autenticar(correo,numCuenta,"ESTUDIANTE");
            if(u==null){m.put("status","error");m.put("message","Correo o número de cuenta incorrectos");}
            else {m.put("status","success");m.put("nombre",u.get("nombre"));m.put("file_key",numCuenta);}
        }catch(IllegalStateException e){m.put("status","error");m.put("message",e.getMessage());}
        return m;
    }
}
