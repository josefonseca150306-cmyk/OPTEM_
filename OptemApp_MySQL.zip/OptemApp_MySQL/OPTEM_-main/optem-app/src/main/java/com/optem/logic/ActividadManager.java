package com.optem.logic;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import com.optem.database.OptemRepository;
import com.optem.models.Actividad;

public class ActividadManager {
    private static final ActividadManager INSTANCE = new ActividadManager();
    private String usuarioActual;
    private ActividadManager() {}
    public static ActividadManager getInstance(){return INSTANCE;}
    public void setUsuarioActual(String correo){this.usuarioActual=correo;}
    public String getUsuarioActual(){return usuarioActual;}
    public List<Actividad> getAllActividades(){return OptemRepository.actividades(usuarioActual);}
    public List<Actividad> getActividadesDelDia(LocalDate fecha){
        return getAllActividades().stream().filter(a->fecha.equals(a.getFecha())).collect(Collectors.toList());
    }
    public void agregarActividad(Actividad act){
        if(usuarioActual==null||usuarioActual.isBlank())throw new IllegalStateException("Inicia sesión antes de guardar actividades");
        OptemRepository.insertarActividad(usuarioActual,act);
    }
    public void actualizarEstadoActividad(String id,String estado){OptemRepository.estadoActividad(usuarioActual,id,estado);}
    public boolean eliminarActividad(String id){return OptemRepository.borrarActividad(usuarioActual,id);}
    public boolean editarActividad(Actividad act){return OptemRepository.editarActividad(usuarioActual,act);}
}
