package com.optem.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.optem.database.ConsultasAcademicas;
import com.optem.database.MySQL;
import com.optem.database.OptemRepository;
import java.sql.*;
import java.util.prefs.Preferences;
import com.optem.ui.DashboardView;

public class ReinscripcionController {

    public static class MateriaDTO {
        public String titulo, creditos, colorBorde, categoria;
        public boolean mixta;
        public String[] opciones;
        public MateriaDTO(String t, String c, boolean m, String cb, String cat, String[] o) { 
            titulo=t; creditos=c; mixta=m; colorBorde=cb; categoria=cat; opciones=o; 
        }
    }

    public static class BloqueHorario {
        public String texto, colorHex;
        public int colDia, rowHora, duracion;
        public BloqueHorario(String t, int c, int r, int d, String ch) { texto=t; colDia=c; rowHora=r; duracion=d; colorHex=ch; }
    }

    public List<MateriaDTO> getMateriasDisponibles() {
        return ConsultasAcademicas.obtenerMateriasReinscripcion();
    }

    public Map<String, String> generarHorarioInteligente(String preferencia) {
        return ConsultasAcademicas.obtenerHorarioIA(preferencia);
    }

    public List<BloqueHorario> procesarSeleccion(String materia,String seleccion,String color){
        List<BloqueHorario> bloques=new ArrayList<>();
        if(seleccion==null || seleccion.contains("No cursar"))return bloques;
        String h=seleccion.contains(" · ")?seleccion.substring(seleccion.indexOf(" · ")+3):seleccion;
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("([0-9]{1,2}):([0-9]{2})\\s*-\\s*([0-9]{1,2}):([0-9]{2})").matcher(h);
        if(!matcher.find())return bloques;
        int inicio=Integer.parseInt(matcher.group(1));int fin=Integer.parseInt(matcher.group(3));
        int row=inicio-7;int duracion=Math.max(1,fin-inicio);
        if(row<0 || row+duracion>13)return bloques;
        String dia=h.toLowerCase(java.util.Locale.ROOT);
        int[][] dias={{1},{2},{3},{4},{5},{6}};
        String[] nombres={"lun","mar","mie","jue","vie","sab"};
        dia=java.text.Normalizer.normalize(dia,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        for(int k=0;k<nombres.length;k++){
            if(dia.contains(nombres[k])) bloques.add(new BloqueHorario(materia,dias[k][0],row,duracion,color));
        }
        return bloques;
    }

    /** Stores a request, not a final official inscription; administrative validation is still required. */
    public boolean guardarSolicitudes(Map<String,String> seleccion) {
        String correo=Preferences.userNodeForPackage(DashboardView.class).get("LAST_ACTIVE_ACCOUNT","");
        if(!"ESTUDIANTE".equals(OptemRepository.rolDeUsuario(correo)) || seleccion==null || seleccion.isEmpty())return false;
        String sql="INSERT INTO SOLICITUD_REINSCRIPCION(correo_estudiante,id_grupo,id_periodo,estado) " +
            "SELECT ?,g.id_grupo,p.id_periodo,'pendiente' FROM GRUPOS g JOIN PERIODOS_ESCOLARES p ON p.estado='activo' " +
            "WHERE g.nombre_grupo=? AND g.horario_texto=? AND p.id_periodo=(SELECT MAX(id_periodo) FROM PERIODOS_ESCOLARES WHERE estado='activo') " +
            "ON DUPLICATE KEY UPDATE estado='pendiente',fecha_solicitud=CURRENT_TIMESTAMP";
        try(Connection c=MySQL.conectar()){
            c.setAutoCommit(false);
            int guardados=0;
            try(PreparedStatement p=c.prepareStatement(sql)){
                for(String opcion:seleccion.values()){
                    if(opcion==null || opcion.startsWith("—") || !opcion.contains(" · "))continue;
                    String[] div=opcion.split(" · ",2);
                    if(div.length!=2)continue;
                    p.setString(1,correo);p.setString(2,div[0]);p.setString(3,div[1]);
                    guardados+=p.executeUpdate();
                }
                if(guardados==0){c.rollback();return false;}
                c.commit();return true;
            }catch(SQLException e){c.rollback();System.err.println("Solicitud reinscripción: "+e.getMessage());return false;}
            finally{c.setAutoCommit(true);}
        }catch(SQLException e){System.err.println("Solicitud reinscripción: "+e.getMessage());return false;}
    }
}
