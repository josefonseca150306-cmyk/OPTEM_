package com.optem.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.optem.database.ConsultasAcademicas;
import com.optem.database.MySQL;
import java.sql.*;

public class ReunionesController {

    private final List<UsuarioDirectorio> directorio = new ArrayList<>();

    public ReunionesController() {
        // Directory is always read from USUARIOS; never pretend sample contacts are online.
    }

    public List< Map < String , String >> getGruposParaLlamada() {
        return ConsultasAcademicas.obtenerMateriasRegistradas();
    }

    public List<UsuarioDirectorio> buscarUsuarios(String query) {
        if (query == null || query.trim().isEmpty()) {
            return new ArrayList<>();
        }
        List<UsuarioDirectorio> resultados=new ArrayList<>();
        String sql="SELECT u.numero_cuenta, CONCAT_WS(' ',u.nombre,u.apellidos) nombre, r.nombre_rol,u.correo " +
                   "FROM USUARIOS u JOIN ROLES r ON r.id_rol=u.id_rol WHERE LOWER(CONCAT_WS(' ',u.nombre,u.apellidos)) LIKE ? " +
                   "OR u.numero_cuenta LIKE ? OR LOWER(u.correo) LIKE ? ORDER BY u.nombre LIMIT 30";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)) {
            String q="%"+query.trim().toLowerCase(java.util.Locale.ROOT)+"%";
            p.setString(1,q);p.setString(2,q);p.setString(3,q);
            try(ResultSet r=p.executeQuery()) {while(r.next()) resultados.add(new UsuarioDirectorio(
                r.getString(1),r.getString(2),r.getString(3),r.getString(4),"Desconocido"));}
        } catch(SQLException e) {System.err.println("Directorio MySQL: "+e.getMessage());}
        return resultados;
    }

    public static class UsuarioDirectorio {
        public String matricula;
        public String nombre;
        public String rol;
        public String correo;
        public String estado;

        public UsuarioDirectorio(String matricula, String nombre, String rol, String correo, String estado) {
            this.matricula = matricula;
            this.nombre = nombre;
            this.rol = rol;
            this.correo = correo;
            this.estado = estado;
        }
    }
}