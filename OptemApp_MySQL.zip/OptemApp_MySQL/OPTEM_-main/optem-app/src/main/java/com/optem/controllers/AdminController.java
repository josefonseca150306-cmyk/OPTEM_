package com.optem.controllers;

import com.optem.database.MySQL;
import java.sql.*;
import java.util.*;
import java.util.prefs.Preferences;
import com.optem.ui.DashboardView;

public class AdminController {
    private String actual(){return Preferences.userNodeForPackage(DashboardView.class).get("LAST_ACTIVE_ACCOUNT","");}
    public String obtenerEstadoServidor(){
        long inicio=System.nanoTime();
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM USUARIOS")) {
            try(ResultSet rs=p.executeQuery()){rs.next();long ms=(System.nanoTime()-inicio)/1_000_000;
                return "🟢 MySQL conectado | Latencia: " + ms + " ms | Usuarios registrados: " + rs.getInt(1);
            }
        }catch(SQLException e){return "🔴 MySQL no disponible: " + e.getMessage();}
    }
    public boolean ejecutarRespaldoBD(){
        // Backups require a separate protected server-side mysqldump job; never report success without one.
        return false;
    }
    public boolean isReinscripcionActiva(){
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT valor FROM CONFIG_SISTEMA WHERE clave='REINSCRIPCION_ABIERTA'")) {
            try(ResultSet r=p.executeQuery()){return r.next() && "1".equals(r.getString(1));}
        }catch(SQLException e){System.err.println("Estado reinscripción: "+e.getMessage());return false;}
    }
    public void toggleReinscripcion(boolean estado){
        String sql="UPDATE CONFIG_SISTEMA SET valor=? WHERE clave='REINSCRIPCION_ABIERTA' " +
            "AND EXISTS(SELECT 1 FROM USUARIOS u JOIN ROLES r ON r.id_rol=u.id_rol WHERE u.correo=? AND r.nombre_rol='Administrador')";
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,estado?"1":"0");p.setString(2,actual());
            if(p.executeUpdate()==0)throw new IllegalStateException("Sin permisos de administrador para cambiar reinscripción.");
        }catch(SQLException e){throw new IllegalStateException("No se pudo guardar la reinscripción: "+e.getMessage(),e);}
    }
    public String[] obtenerInfoContacto(String numeroCuenta) {
        if(numeroCuenta==null || numeroCuenta.isBlank())return null;
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT CONCAT_WS(' ',nombre,apellidos),correo FROM USUARIOS WHERE numero_cuenta=?")) {
            p.setString(1,numeroCuenta);try(ResultSet r=p.executeQuery()){
                if(r.next())return new String[]{r.getString(1),"N/D",r.getString(2),"N/D","N/D","N/D","N/D","N/D","N/D","N/D"};
            }
        }catch(SQLException e){System.err.println("Contacto: "+e.getMessage());}
        return null;
    }
    public List<String> obtenerDocumentosIngreso(String numeroCuenta) {
        return List.of("Sin documentos de ingreso registrados en la base de datos OPTEM.");
    }
    public String[] obtenerIndicadoresRiesgo(String numeroCuenta) {
        return new String[]{"N/D","N/D","N/D","Sin historial de calificaciones académicas","N/D","No evaluado"};
    }
    public String generarHorarioInteligente(String numeroCuenta) {
        return "No se pueden validar seriaciones ni créditos mínimos/máximos sin las reglas oficiales del plan de estudios y el historial académico. Se muestran solo los grupos registrados en MySQL.";
    }
    public String evaluarRecompensas() {
        return "Los logros y la experiencia se almacenan por alumno. No hay suficientes datos oficiales para otorgar becas ni evaluar docentes automáticamente.";
    }
}
