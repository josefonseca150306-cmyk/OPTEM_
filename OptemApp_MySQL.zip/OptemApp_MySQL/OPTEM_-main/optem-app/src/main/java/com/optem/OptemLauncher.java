package com.optem;

/**
 * Punto de entrada para ejecutar OPTEM desde el depurador de VS Code.
 * Se conserva MainApp y su interfaz sin cambios.
 */
public final class OptemLauncher {
    private OptemLauncher() { }

    public static void main(String[] args) {
        javafx.application.Application.launch(MainApp.class, args);
    }
}
