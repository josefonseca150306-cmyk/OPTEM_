package com.optem.controllers;

import com.optem.database.MySQL;
import com.optem.database.OptemRepository;
import java.sql.*;
import java.util.*;
import java.util.prefs.Preferences;
import com.optem.ui.DashboardView;

/** Only actual MySQL students may be enrolled; no dummy accounts are created. */
public class GruposMaestroController {
    private int ultimoGrupoId;
    private String correo() {return Preferences.userNodeForPackage(DashboardView.class).get("LAST_ACTIVE_ACCOUNT","");}
    public String generarCodigoClase() {return ultimoGrupoId > 0 ? codigo(ultimoGrupoId) : "SIN-CODIGO";}
    public String codigo(int id){return String.format("OPT%06d",id);}
    public List<Map<String,String>> misGrupos(){return OptemRepository.gruposDocente(correo());}
    public boolean crearGrupo(String nombreMateria,String horario) {
        if (nombreMateria==null || nombreMateria.isBlank() || horario==null || horario.isBlank()) return false;
        try(Connection c=MySQL.conectar()) {
            String clave=OptemRepository.claveMateria(c,nombreMateria.trim());
            if(clave==null) throw new IllegalArgumentException("La materia debe existir en MATERIAS.");
            String cuenta=correo();
            try(PreparedStatement role=c.prepareStatement("SELECT 1 FROM USUARIOS u JOIN ROLES r ON u.id_rol=r.id_rol WHERE u.correo=? AND r.nombre_rol='Docente'")) {
                role.setString(1,cuenta);try(ResultSet rr=role.executeQuery()){
                    if(!rr.next())throw new IllegalArgumentException("Solo un docente registrado puede crear grupos.");
                }
            }
            String nombre="OPT-"+java.util.UUID.randomUUID().toString().substring(0,8).toUpperCase(Locale.ROOT);
            try(PreparedStatement x=c.prepareStatement("INSERT INTO GRUPOS(clave_materia,nombre_grupo,correo_docente,horario_texto) VALUES(?,?,?,?)",Statement.RETURN_GENERATED_KEYS)) {
                x.setString(1,clave);x.setString(2,nombre);x.setString(3,cuenta);x.setString(4,horario.trim());
                x.executeUpdate();try(ResultSet rs=x.getGeneratedKeys()){if(rs.next())ultimoGrupoId=rs.getInt(1);}
            }
            return ultimoGrupoId>0;
        }catch(SQLException | IllegalArgumentException e){System.err.println("No se pudo crear grupo: "+e.getMessage());return false;}
    }
    public enum ResultadoInscripcion {
        INSCRITO, YA_INSCRITO, ALUMNO_NO_ENCONTRADO, NOMBRE_AMBIGUO,
        GRUPO_INVALIDO, GRUPO_NO_PROPIO, SIN_PERIODO_ACTIVO, ERROR_BASE_DATOS
    }

    /** Busca alumnos reales por matrícula, correo o nombre completo/parcial. */
    public ResultadoInscripcion inscribirAlumno(String codigoGrupo, String busqueda) {
        if (busqueda == null || busqueda.isBlank()) return ResultadoInscripcion.ALUMNO_NO_ENCONTRADO;
        if (codigoGrupo == null || !codigoGrupo.matches("OPT[0-9]{6}")) return ResultadoInscripcion.GRUPO_INVALIDO;
        int idGrupo = Integer.parseInt(codigoGrupo.substring(3));
        try (Connection c = MySQL.conectar()) {
            // Solo permitir inscribir alumnos a grupos asignados al docente activo.
            try (PreparedStatement p = c.prepareStatement(
                "SELECT 1 FROM GRUPOS WHERE id_grupo=? AND correo_docente=? AND archivado=0")) {
                p.setInt(1, idGrupo);
                p.setString(2, correo());
                try (ResultSet r = p.executeQuery()) {
                    if (!r.next()) return ResultadoInscripcion.GRUPO_NO_PROPIO;
                }
            }
            String filtro = busqueda.trim();
            List<String> coincidencias = new ArrayList<>();
            String buscarSql = "SELECT u.correo FROM USUARIOS u JOIN ROLES r ON u.id_rol=r.id_rol " +
                "WHERE r.nombre_rol='Estudiante' AND " +
                "(u.numero_cuenta=? OR LOWER(u.correo)=LOWER(?) OR " +
                "LOWER(CONCAT_WS(' ',u.nombre,u.apellidos)) LIKE LOWER(?)) LIMIT 3";
            try (PreparedStatement p = c.prepareStatement(buscarSql)) {
                p.setString(1, filtro);
                p.setString(2, filtro);
                p.setString(3, "%" + filtro + "%");
                try (ResultSet r = p.executeQuery()) {
                    while (r.next()) coincidencias.add(r.getString(1));
                }
            }
            if (coincidencias.isEmpty()) return ResultadoInscripcion.ALUMNO_NO_ENCONTRADO;
            if (coincidencias.size() != 1) return ResultadoInscripcion.NOMBRE_AMBIGUO;
            String estudiante = coincidencias.get(0);
            int periodo;
            try (PreparedStatement p = c.prepareStatement(
                "SELECT id_periodo FROM PERIODOS_ESCOLARES WHERE estado='activo' " +
                "ORDER BY fecha_inicio DESC LIMIT 1"); ResultSet r = p.executeQuery()) {
                if (!r.next()) return ResultadoInscripcion.SIN_PERIODO_ACTIVO;
                periodo = r.getInt(1);
            }
            try (PreparedStatement p = c.prepareStatement(
                "SELECT 1 FROM CARGA_ACADEMICA WHERE correo_estudiante=? AND id_grupo=? AND id_periodo=?")) {
                p.setString(1, estudiante);
                p.setInt(2, idGrupo);
                p.setInt(3, periodo);
                try (ResultSet r = p.executeQuery()) {
                    if (r.next()) return ResultadoInscripcion.YA_INSCRITO;
                }
            }
            try (PreparedStatement p = c.prepareStatement(
                "INSERT INTO CARGA_ACADEMICA(correo_estudiante,id_grupo,id_periodo,estado_inscripcion) " +
                "VALUES(?,?,?,'inscrito')")) {
                p.setString(1, estudiante);
                p.setInt(2, idGrupo);
                p.setInt(3, periodo);
                return p.executeUpdate() == 1 ? ResultadoInscripcion.INSCRITO : ResultadoInscripcion.ERROR_BASE_DATOS;
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            System.err.println("Alumno ya inscrito o restricción: " + e.getMessage());
            return ResultadoInscripcion.YA_INSCRITO;
        } catch (SQLException e) {
            System.err.println("No se pudo inscribir alumno: " + e.getMessage());
            return ResultadoInscripcion.ERROR_BASE_DATOS;
        }
    }

    public boolean agregarAlumnoManual(String codigoGrupo, String busqueda) {
        return inscribirAlumno(codigoGrupo, busqueda) == ResultadoInscripcion.INSCRITO;
    }
}
