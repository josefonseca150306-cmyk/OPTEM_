package com.optem.database;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.*;

public class ConsultasAcademicas {

    public static boolean autenticar(String correo, String password, String rol) {
        return OptemRepository.autenticar(correo,password,rol)!=null;
    }
    public static Map<String,String> obtenerPerfilUsuario() {
        return OptemRepository.perfil(usuarioActual());
    }
    public static List<Map<String,String>> obtenerMateriasRegistradas() {
        return OptemRepository.materias(usuarioActual());
    }
    private static String usuarioActual() {
        return java.util.prefs.Preferences.userNodeForPackage(com.optem.ui.DashboardView.class).get("LAST_ACTIVE_ACCOUNT", "");
    }

    public static List<com.optem.controllers.ReinscripcionController.MateriaDTO> obtenerMateriasReinscripcion() {
        List<com.optem.controllers.ReinscripcionController.MateriaDTO> lista = new ArrayList<>();
        String q="SELECT m.clave_materia,m.nombre_materia,m.creditos,m.es_mixta,g.nombre_grupo,g.horario_texto " +
            "FROM MATERIAS m JOIN GRUPOS g ON g.clave_materia=m.clave_materia ORDER BY m.nombre_materia,g.nombre_grupo";
        Map<String,List<String>> grupos=new java.util.LinkedHashMap<>();
        Map<String,String> metadata=new java.util.HashMap<>();
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(q);ResultSet r=p.executeQuery()) {
            while(r.next()) {
                String clave=r.getString(1);String materia=r.getString(2);
                String opcion=r.getString(5)+" · "+java.util.Objects.toString(r.getString(6),"Sin horario");
                grupos.computeIfAbsent(clave,k->new ArrayList<>(List.of("— No cursar —"))).add(opcion);
                metadata.put(clave,materia+"|"+r.getInt(3)+"|"+r.getBoolean(4));
            }
        }catch(SQLException e){System.err.println("Reinscripción MySQL: "+e.getMessage());return lista;}
        for(Map.Entry<String,List<String>> entry:grupos.entrySet()) {
            String[] d=metadata.get(entry.getKey()).split("[|]");
            lista.add(new com.optem.controllers.ReinscripcionController.MateriaDTO(d[0],d[1]+" créditos",Boolean.parseBoolean(d[2]),
                "#3F51B5","REGULAR",entry.getValue().toArray(new String[0])));
        }
        return lista;
    }

    public static Map<String,String> obtenerHorarioIA(String preferencia) {
        Map<String,String> sugerencias=new java.util.LinkedHashMap<>();
        for(com.optem.controllers.ReinscripcionController.MateriaDTO m:obtenerMateriasReinscripcion()) {
            for(int i=1;i<m.opciones.length;i++) {
                String o=m.opciones[i].toLowerCase(java.util.Locale.ROOT);
                boolean admite=switch(preferencia) {
                    case "MATUTINO" -> o.matches(".*(?:07:|08:|09:|10:|11:).*" );
                    case "TARDES" -> o.matches(".*(?:12:|13:|14:|15:|16:|17:|18:).*" );
                    case "SIN_VIERNES" -> !o.contains("viernes")&&!o.contains("vie");
                    default -> true;
                };
                if(admite) {sugerencias.put(m.titulo,m.opciones[i]);break;}
            }
        }
        return sugerencias;
    }
}
