-- ATENCION: DESTRUYE TODOS LOS REGISTROS salvo USUARIOS, MATERIAS y ROLES.
-- Conserva la estructura de todas las tablas, pero borra tambien datos reales
-- de prueba como fotografias, reuniones, entregas, grupos, notas y actividades.
-- EJECUTAR SOLO DESPUES DE RESPALDAR optem_db.
USE optem_db;

CREATE TABLE IF NOT EXISTS PUBLICACIONES_GRUPO (
    id_publicacion BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_grupo INT NOT NULL,
    correo_autor VARCHAR(150) COLLATE utf8mb4_unicode_ci NOT NULL,
    contenido TEXT NOT NULL,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_publicaciones_grupo FOREIGN KEY (id_grupo)
        REFERENCES GRUPOS(id_grupo) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_publicaciones_autor FOREIGN KEY (correo_autor)
        REFERENCES USUARIOS(correo) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_publicaciones_grupo_fecha (id_grupo,fecha_creacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Limpieza ordenada por dependencias, sin desactivar restricciones FK.
-- Requiere que previamente se hayan instalado las migraciones 2.1 y 2.3.
START TRANSACTION;
DELETE FROM PUBLICACIONES_GRUPO;
DELETE FROM LOGROS_USUARIO;
DELETE FROM ENTREGAS;
DELETE FROM ASISTENCIAS;
DELETE FROM SOLICITUD_REINSCRIPCION;
DELETE FROM REUNIONES;
DELETE FROM ACTIVIDADES;
DELETE FROM NOTAS;
DELETE FROM RECURSOS_BIBLIOGRAFICOS;
DELETE FROM CARGA_ACADEMICA;
DELETE FROM GRUPOS;
DELETE FROM PERIODOS_ESCOLARES;
DELETE FROM LOGROS;
DELETE FROM PREFERENCIAS_USUARIO;
DELETE FROM CATEGORIAS_ACTIVIDAD;
DELETE FROM CONFIG_SISTEMA;
COMMIT;

-- Verificacion de conservacion de cuentas y catalogo de materias.
SELECT COUNT(*) AS usuarios_conservados FROM USUARIOS;
SELECT COUNT(*) AS materias_conservadas FROM MATERIAS;
SELECT COUNT(*) AS grupos_restantes FROM GRUPOS;
SELECT COUNT(*) AS publicaciones_restantes FROM PUBLICACIONES_GRUPO;

-- IMPORTANTE: despues de esta limpieza necesitas registrar un periodo escolar
-- VERDADERO en PERIODOS_ESCOLARES antes de inscribir alumnos en grupos nuevos.
