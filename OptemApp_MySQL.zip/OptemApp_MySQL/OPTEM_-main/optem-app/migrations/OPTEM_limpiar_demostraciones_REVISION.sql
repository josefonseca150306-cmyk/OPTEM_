USE optem_db;
-- SOLO CONSULTAS. No modifica ni borra datos.
-- Datos introducidos por el SQL inicial de demostración.
-- Revisa los resultados antes de autorizar cualquier eliminación.
SELECT 'PERIODO DEMO' origen, id_periodo identificador, nombre_periodo descripcion
FROM PERIODOS_ESCOLARES WHERE nombre_periodo='Periodo de prueba OPTEM';
SELECT 'GRUPO DEMO' origen, id_grupo identificador, nombre_grupo descripcion
FROM GRUPOS WHERE nombre_grupo IN ('S6-ISWK08','S6-ISWK11','S6-L40834','S6-L40852','S6-ISWK16','S6-L40812','S6-L40849','S6-ISWK14');
SELECT 'ACTIVIDAD DEMO' origen, id_actividad identificador, titulo descripcion
FROM ACTIVIDADES WHERE (correo_usuario,titulo) IN (
('ahernandezh058@alumno.uaemex.mx','Modelo de proceso de software'),
('ahernandezh058@alumno.uaemex.mx','Consultas SQL básicas'),
('ahernandezh058@alumno.uaemex.mx','Diagrama de casos de uso'),
('fmartinezc017@alumno.uaemex.mx','Calidad del proceso'),
('fmartinezc017@alumno.uaemex.mx','Especificación de requisitos'),
('fmartinezc017@alumno.uaemex.mx','Cronograma del proyecto'),
('jfonsecal001@alumno.uaemex.mx','Modelo entidad-relación'),
('jfonsecal001@alumno.uaemex.mx','Principios de POO'),
('jfonsecal001@alumno.uaemex.mx','Plan de pruebas'),
('oramosg002@uaemex.mx','Documentación de OPTEM'),
('oramosg002@uaemex.mx','Integración de MySQL'),
('oramosg002@uaemex.mx','Prototipo de interfaz'));
SELECT 'NOTA DEMO' origen, id_nota identificador, titulo descripcion
FROM NOTAS WHERE (correo_usuario,titulo) IN (
('ahernandezh058@alumno.uaemex.mx','Apuntes de ingeniería de software'),
('fmartinezc017@alumno.uaemex.mx','Requisitos del sistema'),
('jfonsecal001@alumno.uaemex.mx','SQL y modelo relacional'),
('oramosg002@uaemex.mx','Pendientes de OPTEM'));
SELECT 'RECURSO DEMO' origen, id_recurso identificador, titulo descripcion
FROM RECURSOS_BIBLIOGRAFICOS WHERE titulo IN
('Ingeniería de software: un enfoque práctico','Fundamentos de bases de datos',
'Análisis y diseño de sistemas','Software Requirements','Administración de proyectos','Software Quality Engineering');
SELECT 'DOCENTE DE PRUEBA (REVISAR)' origen, numero_cuenta identificador, correo descripcion
FROM USUARIOS WHERE correo='docente.prueba@optem.local';
-- No se incluyen en la limpieza automatizada las notas, fotos, tareas, reuniones
-- ni otras operaciones creadas por alumnos y docentes durante las pruebas.
