USE optem_db;

-- Migracion corregida Fase 2. Compatible con optem_db creado con utf8mb4_unicode_ci.
-- Seguro para reintentos tras una ejecucion parcial: comprueba columnas existentes.
-- No elimina datos ni tablas existentes.
-- Asegura que las nuevas tablas usan la misma intercalacion que las FK de USUARIOS.
DELIMITER $$
DROP PROCEDURE IF EXISTS optem_agregar_columna_fase2$$
CREATE PROCEDURE optem_agregar_columna_fase2(IN tabla VARCHAR(64),IN columna VARCHAR(64),IN definicion VARCHAR(200))
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=tabla AND COLUMN_NAME=columna
    ) THEN
        SET @ddl = CONCAT('ALTER TABLE `', tabla, '` ADD COLUMN `', columna, '` ', definicion);
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

CALL optem_agregar_columna_fase2('PREFERENCIAS_USUARIO','foto_perfil','LONGBLOB NULL');
CALL optem_agregar_columna_fase2('PREFERENCIAS_USUARIO','foto_mime','VARCHAR(50) NULL');
CALL optem_agregar_columna_fase2('ENTREGAS','archivo_nombre','VARCHAR(255) NULL');
CALL optem_agregar_columna_fase2('ENTREGAS','archivo_datos','LONGBLOB NULL');
CALL optem_agregar_columna_fase2('ENTREGAS','archivo_tipo','VARCHAR(120) NULL');
DROP PROCEDURE IF EXISTS optem_agregar_columna_fase2;

CREATE TABLE IF NOT EXISTS REUNIONES (
    id_reunion INT AUTO_INCREMENT PRIMARY KEY,
    id_grupo INT NULL,
    titulo VARCHAR(200) NOT NULL,
    enlace VARCHAR(512) NOT NULL,
    creado_por VARCHAR(150) NOT NULL,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reuniones_grupo FOREIGN KEY (id_grupo) REFERENCES GRUPOS(id_grupo) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_reuniones_creador FOREIGN KEY (creado_por) REFERENCES USUARIOS(correo) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT uq_reuniones_enlace UNIQUE (enlace),
    CONSTRAINT uq_reuniones_grupo UNIQUE (id_grupo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS CONFIG_SISTEMA (
  clave VARCHAR(80) PRIMARY KEY,
  valor VARCHAR(200) NOT NULL,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO CONFIG_SISTEMA(clave,valor) VALUES ('REINSCRIPCION_ABIERTA','0');

CREATE TABLE IF NOT EXISTS SOLICITUD_REINSCRIPCION (
  id_solicitud INT AUTO_INCREMENT PRIMARY KEY,
  correo_estudiante VARCHAR(150) NOT NULL,
  id_grupo INT NOT NULL,
  id_periodo INT NOT NULL,
  estado VARCHAR(30) NOT NULL DEFAULT 'pendiente',
  fecha_solicitud TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_solreins_estudiante FOREIGN KEY (correo_estudiante) REFERENCES USUARIOS(correo) ON DELETE CASCADE,
  CONSTRAINT fk_solreins_grupo FOREIGN KEY (id_grupo) REFERENCES GRUPOS(id_grupo) ON DELETE CASCADE,
  CONSTRAINT fk_solreins_periodo FOREIGN KEY (id_periodo) REFERENCES PERIODOS_ESCOLARES(id_periodo),
  CONSTRAINT uq_solreins UNIQUE (correo_estudiante,id_grupo,id_periodo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'PREFERENCIAS_USUARIO' AS tabla, COLUMN_NAME AS columna
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='PREFERENCIAS_USUARIO' AND COLUMN_NAME IN ('foto_perfil','foto_mime')
UNION ALL
SELECT 'ENTREGAS', COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ENTREGAS' AND COLUMN_NAME IN ('archivo_nombre','archivo_datos','archivo_tipo');
SHOW TABLES;

