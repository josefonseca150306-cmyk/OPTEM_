package com.optem.database;
import java.sql.*;
/** Conexión centralizada, sin credenciales dentro del repositorio. */
public final class MySQL {
    private MySQL() {}
    public static Connection conectar() throws SQLException {
        String host = System.getenv().getOrDefault("OPTEM_DB_HOST", "100.67.119.35");
        String port = System.getenv().getOrDefault("OPTEM_DB_PORT", "3306");
        String db = System.getenv().getOrDefault("OPTEM_DB_NAME", "optem_db");
        String usuario = System.getenv("OPTEM_DB_USER");
        String clave = System.getenv("OPTEM_DB_PASSWORD");
        if (usuario == null || usuario.isBlank() || clave == null || clave.isBlank())
            throw new SQLException("Configura OPTEM_DB_USER y OPTEM_DB_PASSWORD en VS Code.");
        return DriverManager.getConnection("jdbc:mysql://"+host+":"+port+"/"+db+"?useUnicode=true&characterEncoding=UTF-8&connectTimeout=6000", usuario, clave);
    }
}
