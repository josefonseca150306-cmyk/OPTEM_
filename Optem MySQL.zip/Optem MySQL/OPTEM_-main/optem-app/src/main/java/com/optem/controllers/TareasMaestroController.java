package com.optem.controllers;
import com.optem.database.*;
import java.io.*;
import java.sql.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;

/** Asignaciones y entregas compartidas por grupo con archivos guardados en MySQL. */
public class TareasMaestroController {
    private String correo(){return MockDB.sesion();}
    public List<String> getMisGruposOficiales(){
        List<String> list=new ArrayList<>();
        for(Map<String,String> g:MockDB.obtenerTodosLosGrupos())list.add(g.get("nombre")+" ("+g.get("grupo")+")");
        return list;
    }
    public void publicarNuevaTarea(String titulo,String materia,String descripcion,LocalDate fecha,String hora,String rutaArchivo){
        if(fecha==null||titulo==null||titulo.isBlank()||materia==null)throw new IllegalArgumentException("Selecciona grupo, título y fecha límite");
        String sql="INSERT INTO OPTEM_ASIGNACIONES_DOCENTE(id_grupo,correo_docente,titulo,descripcion,fecha_limite,hora_limite,archivo_nombre,archivo_contenido,estado) VALUES (?,?,?,?,?,?,?,?, 'ABIERTA')";
        byte[] bytes=leerArchivo(rutaArchivo);
        try(Connection c=MySQL.conectar()){
            int idGrupo=-1;
            for(Map<String,String> g:MockDB.obtenerTodosLosGrupos()){
                if((g.get("nombre")+" ("+g.get("grupo")+")").equals(materia)) {idGrupo=Integer.parseInt(g.get("id_grupo"));break;}
            }
            if(idGrupo<0)throw new IllegalArgumentException("Ese grupo no pertenece a tu cuenta docente");
            try(PreparedStatement p=c.prepareStatement(sql)){
                p.setInt(1,idGrupo);p.setString(2,correo());p.setString(3,titulo);p.setString(4,descripcion);
                p.setDate(5,java.sql.Date.valueOf(fecha));p.setString(6,hora);
                if(bytes==null){p.setNull(7,Types.VARCHAR);p.setNull(8,Types.BLOB);}
                else {p.setString(7,Path.of(rutaArchivo).getFileName().toString());p.setBytes(8,bytes);}
                p.executeUpdate();
            }
        }catch(SQLException ex){throw new IllegalStateException("No se pudo publicar la asignación: "+ex.getMessage(),ex);}
    }
    public List<Map<String,String>> getTodasLasAsignaciones(){
        String q="SELECT a.id_asignacion,a.titulo,a.descripcion,a.fecha_limite,a.hora_limite,a.estado,a.archivo_nombre,a.archivo_contenido,m.nombre_materia,g.nombre_grupo,"+
           "(SELECT COUNT(*) FROM OPTEM_ENTREGAS_ASIGNACION e WHERE e.id_asignacion=a.id_asignacion) entregadas,"+
           "(SELECT COUNT(*) FROM CARGA_ACADEMICA ca WHERE ca.id_grupo=g.id_grupo AND ca.estado_inscripcion='inscrito') inscritas " +
           "FROM OPTEM_ASIGNACIONES_DOCENTE a JOIN GRUPOS g ON g.id_grupo=a.id_grupo JOIN MATERIAS m ON m.clave_materia=g.clave_materia " +
           "WHERE a.correo_docente=? OR EXISTS (SELECT 1 FROM CARGA_ACADEMICA ca WHERE ca.id_grupo=a.id_grupo AND ca.correo_estudiante=? AND ca.estado_inscripcion='inscrito') ORDER BY a.id_asignacion DESC";
        List<Map<String,String>> result=new ArrayList<>();
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(q)){
            p.setString(1,correo());p.setString(2,correo());try(ResultSet r=p.executeQuery()){
                while(r.next()){
                    Map<String,String> t=new HashMap<>();
                    t.put("id",r.getString("id_asignacion"));t.put("titulo",r.getString("titulo"));
                    t.put("descripcion",Objects.toString(r.getString("descripcion"),""));t.put("materia",r.getString("nombre_materia")+" ("+r.getString("nombre_grupo")+")");
                    t.put("fecha",r.getString("fecha_limite"));t.put("hora",r.getString("hora_limite"));
                    t.put("estado",r.getString("estado"));t.put("entregas_actuales",r.getString("entregadas"));t.put("entregas_total",r.getString("inscritas"));
                    byte[] blob=r.getBytes("archivo_contenido");
                    t.put("ruta_archivo",blob==null?"":archivoTemporal(r.getString("archivo_nombre"),blob));
                    result.add(t);
                }
            }
        }catch(SQLException ex){throw new IllegalStateException("No se pudieron consultar asignaciones: "+ex.getMessage(),ex);}
        return result;
    }
    public void cerrarRecepcionTarea(String id){
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("UPDATE OPTEM_ASIGNACIONES_DOCENTE SET estado='CERRADA' WHERE id_asignacion=? AND correo_docente=?")){
            p.setLong(1,Long.parseLong(id));p.setString(2,correo());if(p.executeUpdate()!=1)throw new IllegalArgumentException("No se encontró la asignación de tu cuenta");
        }catch(SQLException ex){throw new IllegalStateException(ex);}
    }
    public boolean yaEntregado(String id){
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement("SELECT 1 FROM OPTEM_ENTREGAS_ASIGNACION WHERE id_asignacion=? AND correo_alumno=?")){
            p.setLong(1,Long.parseLong(id));p.setString(2,correo());try(ResultSet r=p.executeQuery()){return r.next();}
        }catch(SQLException ex){throw new IllegalStateException(ex);}
    }
    public void registrarEntregaAlumno(String id,String nombreAlumno,String rutaArchivo){
        byte[] data=leerArchivo(rutaArchivo);if(data==null)throw new IllegalArgumentException("Selecciona un archivo válido");
        String sql="INSERT INTO OPTEM_ENTREGAS_ASIGNACION(id_asignacion,correo_alumno,archivo_nombre,archivo_contenido) " +
           "SELECT a.id_asignacion,?, ?,? FROM OPTEM_ASIGNACIONES_DOCENTE a WHERE a.id_asignacion=? AND a.estado='ABIERTA' AND " +
           "EXISTS (SELECT 1 FROM CARGA_ACADEMICA ca WHERE ca.id_grupo=a.id_grupo AND ca.correo_estudiante=? AND ca.estado_inscripcion='inscrito')";
        try(Connection c=MySQL.conectar()){
            c.setAutoCommit(false);
            try(PreparedStatement p=c.prepareStatement(sql)){
                p.setString(1,correo());p.setString(2,Path.of(rutaArchivo).getFileName().toString());p.setBytes(3,data);p.setLong(4,Long.parseLong(id));p.setString(5,correo());
                if(p.executeUpdate()!=1)throw new IllegalArgumentException("Recepción cerrada, grupo no inscrito o asignación inexistente");
                try(PreparedStatement xp=c.prepareStatement("UPDATE USUARIOS SET xp_total=xp_total+50 WHERE correo=?")){
                    xp.setString(1,correo());xp.executeUpdate();
                }
                c.commit();
            }catch(Exception ex){c.rollback();throw ex;}
        }catch(Exception ex){throw new IllegalStateException("No se guardó la entrega: "+ex.getMessage(),ex);}
    }
    public List<Map<String,String>> obtenerEntregasDeTarea(String id){
        String sql="SELECT u.nombre,u.apellidos,e.fecha_entrega,e.archivo_nombre,e.archivo_contenido FROM OPTEM_ENTREGAS_ASIGNACION e JOIN USUARIOS u ON u.correo=e.correo_alumno JOIN OPTEM_ASIGNACIONES_DOCENTE a ON a.id_asignacion=e.id_asignacion WHERE e.id_asignacion=? AND a.correo_docente=? ORDER BY e.fecha_entrega DESC";
        List<Map<String,String>> list=new ArrayList<>();
        try(Connection c=MySQL.conectar();PreparedStatement p=c.prepareStatement(sql)){
            p.setLong(1,Long.parseLong(id));p.setString(2,correo());try(ResultSet r=p.executeQuery()){
                while(r.next()){
                    Map<String,String> m=new HashMap<>();m.put("alumno",r.getString(1)+" "+r.getString(2));m.put("fecha_entrega",r.getString(3));
                    m.put("ruta",archivoTemporal(r.getString(4),r.getBytes(5)));list.add(m);
                }
            }
        }catch(SQLException ex){throw new IllegalStateException(ex);}return list;
    }
    private static byte[] leerArchivo(String ruta){
        if(ruta==null||ruta.isBlank())return null;
        try{Path p=Path.of(ruta);long tam=Files.size(p);if(tam>20_000_000L)throw new IllegalArgumentException("Archivo máximo 20MB");return Files.readAllBytes(p);}
        catch(IOException ex){throw new IllegalStateException("No se pudo leer el archivo: "+ex.getMessage(),ex);}
    }
    private static String archivoTemporal(String nombre,byte[] contenido){
        if(contenido==null)return "";
        try{
            String n=nombre==null?"archivo.bin":Path.of(nombre).getFileName().toString();
            String extension=n.contains(".")?n.substring(n.lastIndexOf('.')):".bin";
            if(extension.length()>15)extension=".bin";
            Path p=Files.createTempFile("optem_archivo_",extension);Files.write(p,contenido);p.toFile().deleteOnExit();return p.toString();
        }catch(IOException ex){throw new IllegalStateException("No se pudo abrir adjunto: "+ex.getMessage(),ex);}
    }
}
